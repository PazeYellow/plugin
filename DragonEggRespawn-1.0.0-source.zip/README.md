# DragonEggRespawn

A lightweight Purpur plugin for Minecraft 26.1.2.

## Behavior

- The first Dragon Egg in each End world is handled normally by the server.
- Every later Ender Dragon defeat rolls the configured `drop-chance`.
- A successful roll lets Purpur form another egg at the exit portal normally.
- Every egg that actually forms, including the first egg, is announced in-game.
- Optional Discord webhook announcements are sent away from the server thread.
- The configured Discord channel ID is checked against the webhook before any
  messages are sent.

## Install

1. Run Purpur 26.1.2 on Java 25.
2. Put `DragonEggRespawn-1.0.0.jar` in the server's `plugins` folder.
3. Start the server once to create `plugins/DragonEggRespawn/config.yml`.
4. Edit the config and run `/dragoneggrespawn reload` (alias: `/der reload`).

## Chance examples

```yaml
drop-chance: 1     # 100%
drop-chance: 0.25  # 25%
drop-chance: 0.01  # 1%
drop-chance: 0     # 0%
```

## Discord setup

1. In Discord, open **Server Settings -> Integrations -> Webhooks**.
2. Create a webhook, select its destination channel, and copy its URL.
3. Enable Developer Mode in Discord, right-click that same channel, and copy ID.
4. Put both values in `config.yml` and set `discord.enabled` to `true`.
5. Run `/dragoneggrespawn reload`, then `/dragoneggrespawn status`.

The webhook is already tied to a Discord channel. The separate channel ID is a
safety check: the plugin fetches the webhook details and only enables messages
when the two channel IDs match.

## Build from source

Run `mvn clean package` with Maven and JDK 25. The compiled plugin will be in
`target/DragonEggRespawn-1.0.0.jar`.

## Command and permission

- `/dragoneggrespawn reload` - reload the config
- `/dragoneggrespawn status` - show the active chance and Discord status
- Permission: `dragoneggrespawn.admin` (operators have it by default)
