package dev.dragoneggrespawn;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DiscordNotifier implements AutoCloseable {
    private static final Pattern CHANNEL_ID_PATTERN = Pattern.compile(
            "\\\"channel_id\\\"\\s*:\\s*\\\"([0-9]+)\\\""
    );

    private final Logger logger;
    private final ExecutorService executor;
    private final HttpClient httpClient;
    private final AtomicLong configurationGeneration = new AtomicLong();

    private volatile DiscordSettings settings;
    private volatile boolean verified;

    DiscordNotifier(Logger logger) {
        this.logger = logger;
        this.executor = Executors.newSingleThreadExecutor(task -> {
            Thread thread = new Thread(task, "DragonEggRespawn-Discord");
            thread.setDaemon(true);
            return thread;
        });
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    void configure(DiscordSettings newSettings) {
        settings = newSettings;
        verified = false;
        long generation = configurationGeneration.incrementAndGet();

        if (!newSettings.enabled()) {
            logger.info("Discord notifications are disabled.");
            return;
        }

        executor.execute(() -> verifyWebhook(newSettings, generation));
    }

    void send(String message) {
        DiscordSettings current = settings;
        if (current == null || !current.enabled() || !verified) {
            return;
        }

        String payload = buildPayload(message, current.username(), current.avatarUrl());
        HttpRequest request = HttpRequest.newBuilder(withWaitParameter(current.webhookUri()))
                .timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();

        executor.execute(() -> {
            try {
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        logger.warning("Discord rejected a notification with HTTP status " + response.statusCode() + ".");
                    }
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
            } catch (Exception exception) {
                logger.log(Level.WARNING, "Could not send the Discord notification: " + safeMessage(exception));
            }
        });
    }

    boolean isVerified() {
        return verified;
    }

    private void verifyWebhook(DiscordSettings candidate, long generation) {
        HttpRequest request = HttpRequest.newBuilder(candidate.webhookUri())
                .timeout(Duration.ofSeconds(15))
                .GET()
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                logger.warning("Discord webhook verification failed with HTTP status " + response.statusCode() + ".");
                return;
            }

            Matcher matcher = CHANNEL_ID_PATTERN.matcher(response.body());
            if (!matcher.find()) {
                logger.warning("Discord webhook verification failed because its channel ID was not returned.");
                return;
            }
            if (!candidate.channelId().equals(matcher.group(1))) {
                logger.warning("Discord notifications are disabled: discord.channel-id does not match the webhook's channel.");
                return;
            }

            if (configurationGeneration.get() == generation && settings == candidate) {
                verified = true;
                logger.info("Discord webhook verified for channel " + candidate.channelId() + ".");
            }
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        } catch (Exception exception) {
            logger.log(Level.WARNING, "Could not verify the Discord webhook: " + safeMessage(exception));
        }
    }

    private static URI withWaitParameter(URI uri) {
        String separator = uri.getQuery() == null ? "?" : "&";
        return URI.create(uri + separator + "wait=true");
    }

    private static String buildPayload(String content, String username, String avatarUrl) {
        StringBuilder json = new StringBuilder("{\"content\":\"")
                .append(escapeJson(content))
                .append('\"');
        if (!username.isBlank()) {
            json.append(",\"username\":\"").append(escapeJson(username)).append('\"');
        }
        if (!avatarUrl.isBlank()) {
            json.append(",\"avatar_url\":\"").append(escapeJson(avatarUrl)).append('\"');
        }
        return json.append('}').toString();
    }

    private static String escapeJson(String value) {
        StringBuilder escaped = new StringBuilder(value.length() + 16);
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            switch (character) {
                case '\"' -> escaped.append("\\\"");
                case '\\' -> escaped.append("\\\\");
                case '\b' -> escaped.append("\\b");
                case '\f' -> escaped.append("\\f");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                default -> {
                    if (character < 0x20) {
                        escaped.append(String.format("\\u%04x", (int) character));
                    } else {
                        escaped.append(character);
                    }
                }
            }
        }
        return escaped.toString();
    }

    private static String safeMessage(Throwable throwable) {
        String message = throwable.getMessage();
        return message == null || message.isBlank() ? throwable.getClass().getSimpleName() : message;
    }

    @Override
    public void close() {
        configurationGeneration.incrementAndGet();
        verified = false;
        executor.shutdownNow();
    }
}
