package dev.dragoneggrespawn;

import org.bukkit.configuration.file.FileConfiguration;

record PluginSettings(
        double dropChance,
        boolean broadcastEnabled,
        String broadcastMessage,
        DiscordSettings discord
) {
    static PluginSettings from(FileConfiguration config) {
        double chance = config.getDouble("drop-chance", 0.10D);
        if (!Double.isFinite(chance) || chance < 0.0D || chance > 1.0D) {
            throw new IllegalArgumentException("drop-chance must be a decimal from 0 to 1");
        }

        String broadcastMessage = requireText(
                config.getString("broadcast.message"),
                "broadcast.message"
        );

        return new PluginSettings(
                chance,
                config.getBoolean("broadcast.enabled", true),
                broadcastMessage,
                DiscordSettings.from(config)
        );
    }

    private static String requireText(String value, String path) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(path + " cannot be empty");
        }
        return value;
    }
}
