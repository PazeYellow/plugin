package dev.dragoneggrespawn;

import java.net.URI;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import org.bukkit.configuration.file.FileConfiguration;

record DiscordSettings(
        boolean enabled,
        URI webhookUri,
        String channelId,
        String username,
        String avatarUrl,
        String message
) {
    private static final Pattern SNOWFLAKE = Pattern.compile("[0-9]{17,20}");
    private static final Set<String> ALLOWED_HOSTS = Set.of(
            "discord.com",
            "www.discord.com",
            "discordapp.com",
            "www.discordapp.com",
            "ptb.discord.com",
            "canary.discord.com"
    );

    static DiscordSettings from(FileConfiguration config) {
        boolean enabled = config.getBoolean("discord.enabled", false);
        String webhook = value(config, "discord.webhook-url");
        String channelId = value(config, "discord.channel-id");
        String username = value(config, "discord.username");
        String avatarUrl = value(config, "discord.avatar-url");
        String message = value(config, "discord.message");

        if (!enabled) {
            return new DiscordSettings(false, null, channelId, username, avatarUrl, message);
        }

        if (webhook.isBlank()) {
            throw new IllegalArgumentException("discord.webhook-url is required when Discord is enabled");
        }
        if (!SNOWFLAKE.matcher(channelId).matches()) {
            throw new IllegalArgumentException("discord.channel-id must be a 17-20 digit Discord channel ID");
        }
        if (message.isBlank()) {
            throw new IllegalArgumentException("discord.message cannot be empty when Discord is enabled");
        }

        URI uri;
        try {
            uri = URI.create(webhook);
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("discord.webhook-url is not a valid URL", exception);
        }

        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(uri.getScheme())
                || host == null
                || !ALLOWED_HOSTS.contains(host.toLowerCase(Locale.ROOT))
                || !uri.getPath().startsWith("/api/webhooks/")) {
            throw new IllegalArgumentException("discord.webhook-url must be an HTTPS Discord webhook URL");
        }

        return new DiscordSettings(true, uri, channelId, username, avatarUrl, message);
    }

    private static String value(FileConfiguration config, String path) {
        String result = config.getString(path, "");
        return result == null ? "" : result.trim();
    }
}
