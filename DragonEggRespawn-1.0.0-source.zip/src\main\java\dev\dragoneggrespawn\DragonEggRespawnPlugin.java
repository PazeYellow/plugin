package dev.dragoneggrespawn;

import io.papermc.paper.event.block.DragonEggFormEvent;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public final class DragonEggRespawnPlugin extends JavaPlugin implements Listener {
    private static final LegacyComponentSerializer LEGACY_MESSAGES =
            LegacyComponentSerializer.legacyAmpersand();

    private volatile PluginSettings settings;
    private DiscordNotifier discordNotifier;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        discordNotifier = new DiscordNotifier(getLogger());

        try {
            applyConfiguration();
        } catch (IllegalArgumentException exception) {
            getLogger().log(Level.SEVERE, "Invalid configuration: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Enabled with a " + formatPercent(settings.dropChance())
                + " repeat Dragon Egg chance.");
    }

    @Override
    public void onDisable() {
        if (discordNotifier != null) {
            discordNotifier.close();
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void chooseRepeatEgg(DragonEggFormEvent event) {
        // The server owns the first egg. Leaving this event untouched preserves
        // normal vanilla/Purpur behavior and avoids ever creating a duplicate.
        if (!event.getDragonBattle().hasBeenPreviouslyKilled()) {
            return;
        }

        double chance = settings.dropChance();
        boolean shouldSpawn = chance >= 1.0D
                || (chance > 0.0D && ThreadLocalRandom.current().nextDouble() < chance);

        // Repeat egg events are cancelled by default. On a successful roll this
        // allows the server to create the egg at the exit portal normally.
        event.setCancelled(!shouldSpawn);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void announceSpawnedEgg(DragonEggFormEvent event) {
        if (event.getNewState().getType() != Material.DRAGON_EGG) {
            return;
        }

        Block target = event.getBlock();
        World world = target.getWorld();
        int x = target.getX();
        int y = target.getY();
        int z = target.getZ();

        // BlockFormEvent applies its new state after listeners return. Check on
        // the next tick so an egg is announced only when it truly appeared.
        getServer().getScheduler().runTask(this, () -> {
            if (world.getBlockAt(x, y, z).getType() == Material.DRAGON_EGG) {
                announce(world.getName());
            }
        });
    }

    private void announce(String worldName) {
        PluginSettings current = settings;
        if (current.broadcastEnabled()) {
            String message = placeholders(current.broadcastMessage(), worldName, current.dropChance());
            getServer().broadcast(LEGACY_MESSAGES.deserialize(message));
        }

        if (current.discord().enabled()) {
            String message = placeholders(current.discord().message(), worldName, current.dropChance());
            discordNotifier.send(message);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            try {
                applyConfiguration();
                sender.sendMessage(LEGACY_MESSAGES.deserialize(
                        "&aDragonEggRespawn reloaded. Repeat egg chance: &f"
                                + formatPercent(settings.dropChance())
                ));
            } catch (IllegalArgumentException exception) {
                sender.sendMessage(LEGACY_MESSAGES.deserialize(
                        "&cReload failed: " + exception.getMessage()
                                + ". The previous settings are still active."
                ));
            }
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
            PluginSettings current = settings;
            String discordStatus = !current.discord().enabled()
                    ? "disabled"
                    : (discordNotifier.isVerified() ? "enabled and verified" : "enabled, awaiting verification");
            sender.sendMessage(LEGACY_MESSAGES.deserialize(
                    "&dDragonEggRespawn &7- repeat chance: &f"
                            + formatPercent(current.dropChance()) + "&7, Discord: &f" + discordStatus
            ));
            return true;
        }

        sender.sendMessage(LEGACY_MESSAGES.deserialize("&cUsage: /" + label + " <reload|status>"));
        return true;
    }

    private void applyConfiguration() {
        PluginSettings candidate = PluginSettings.from(getConfig());
        settings = candidate;
        discordNotifier.configure(candidate.discord());
    }

    private static String placeholders(String message, String worldName, double chance) {
        return message
                .replace("{world}", worldName)
                .replace("{chance}", formatPercent(chance));
    }

    private static String formatPercent(double chance) {
        return String.format(Locale.ROOT, "%.2f%%", chance * 100.0D);
    }

}
